java --module-path /home/medved/IdeaProjects/weather/openjfx-11.0.2_linux-x64_bin-sdk/javafx-sdk-11.0.2/lib/ --add-modules javafx.controls,javafx.fxml -jar weather.jar

